package com.audition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditionApplicationTests {

    // TODO implement unit test. Note that an applicant should create additional unit tests as required.

    @Test
    void contextLoads() {
    }

}
