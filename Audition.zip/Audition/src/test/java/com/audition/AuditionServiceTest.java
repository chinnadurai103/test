package com.audition;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.audition.integration.AuditionIntegrationClient;
import com.audition.model.AuditionPost;
import com.audition.service.AuditionService;

@ExtendWith(MockitoExtension.class)
class AuditionServiceTest {

    @Mock
    private AuditionIntegrationClient auditionIntegrationClient;

    @InjectMocks
    private AuditionService auditionService;

    private AuditionPost post1;
    private AuditionPost post2;

    @BeforeEach
    void setUp() {
        post1 = new AuditionPost();
        post1.setId(1);
        post1.setUserId(101);
        post1.setTitle("Test Title 1");
        post1.setBody("Test Body 1");

        post2 = new AuditionPost();
        post2.setId(2);
        post2.setUserId(102);
        post2.setTitle("Test Title 2");
        post2.setBody("Test Body 2");
    }

    @Test
    void testGetPosts() {
        List<AuditionPost> mockPosts = Arrays.asList(post1, post2);
        when(auditionIntegrationClient.getPosts()).thenReturn(mockPosts);

        List<AuditionPost> result = auditionService.getPosts();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Test Title 1", result.get(0).getTitle());
        verify(auditionIntegrationClient, times(1)).getPosts();
    }

    @Test
    void testGetPostById() {
        String postId = "1";

        when(auditionIntegrationClient.getPostById(postId)).thenReturn(post1);

        AuditionPost result = auditionService.getPostById(postId);

        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals("Test Title 1", result.getTitle());
        verify(auditionIntegrationClient, times(1)).getPostById(postId);
    }

    @Test
    void testGetPostById_NotFound() {
        String postId = "999";

        when(auditionIntegrationClient.getPostById(postId)).thenReturn(null);

        AuditionPost result = auditionService.getPostById(postId);

        assertNull(result);
        verify(auditionIntegrationClient, times(1)).getPostById(postId);
    }
}
