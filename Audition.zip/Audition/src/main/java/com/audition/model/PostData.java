package com.audition.model;

import java.util.List;

public class PostData {
	
	private AuditionPost post;
	private List<Comment> comments;
	public AuditionPost getPost() {
		return post;
	}
	public void setPost(AuditionPost post) {
		this.post = post;
	}
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	
}
