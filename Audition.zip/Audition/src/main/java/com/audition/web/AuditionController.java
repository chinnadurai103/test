package com.audition.web;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.audition.model.AuditionPost;
import com.audition.model.PostData;
import com.audition.service.AuditionService;

@RestController
public class AuditionController {

    @Autowired
    AuditionService  auditionService;

    @RequestMapping(value = "/posts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<AuditionPost> getPostsByfilter(@RequestParam("filter") String filter) {

        if (filter != null && !filter.isEmpty()) {
            return auditionService.getPosts().stream()
                    .filter(post -> post.getTitle().contains(filter)) 
                    .collect(Collectors.toList());
        }
        return auditionService.getPosts();
    }


    @RequestMapping(value = "/posts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AuditionPost getPosts(@PathVariable("id") final String postId) {
    	if(Objects.nonNull(postId)) {
    		return auditionService.getPostById(postId);
    	}
        return null;
    }

    // TODO Add additional methods to return comments for each post. Hint: Check https://jsonplaceholder.typicode.com/

    @RequestMapping(value = "/posts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody PostData getCommnetsBypostId(@PathVariable("id") final String postId) {
    	if(Objects.nonNull(postId)) {
    		PostData result = auditionService.getCommentsByPostId(postId);
    		return result;
    	}
        return null;
    }
    
    @RequestMapping(value = "/posts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody PostData getCommnetsBypostId1(@PathVariable("id") final String postId) {
    	if(Objects.nonNull(postId)) {
    		PostData result = auditionService.getCommentsByPostId1(postId);
    		return result;
    	}
        return null;
    }

}
