package com.audition.configuration;

import org.springframework.stereotype.Component;

@Component
public class ResponseHeaderInjector {

    // TODO Inject openTelemetry trace and span Ids in the response headers.

}
