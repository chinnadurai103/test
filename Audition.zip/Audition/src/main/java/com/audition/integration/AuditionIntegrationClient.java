package com.audition.integration;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.audition.common.exception.SystemException;
import com.audition.model.AuditionPost;
import com.audition.model.Comment;
import com.audition.model.PostData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class AuditionIntegrationClient {

    private static final String AUDITION_LIST_URL = "https://jsonplaceholder.typicode.com/posts/";
	@Autowired
    private RestTemplate restTemplate;

    public List<AuditionPost> getPosts() {
         String jsonResponse = restTemplate.getForObject(AUDITION_LIST_URL, String.class);
         try {
             ObjectMapper objectMapper = new ObjectMapper();
             List<AuditionPost> auditionPosts = objectMapper.readValue(jsonResponse, new TypeReference<List<AuditionPost>>() {});
             auditionPosts.forEach(System.out::println);
             return auditionPosts;
         } catch (Exception e) {
             e.printStackTrace();
         }
         return null;
    }
    
	public AuditionPost getPostById(final String id) {
		String jsonResponse = restTemplate.getForObject(AUDITION_LIST_URL + "/" + id, String.class);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			AuditionPost auditionPosts = objectMapper.readValue(jsonResponse, new TypeReference<AuditionPost>() {
			});
			return auditionPosts;
		} catch (final HttpClientErrorException e) {
			if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
				throw new SystemException("Cannot find a Post with id " + id, "Resource Not Found", 404);
			} else {
				// TODO Find a better way to handle the exception so that the original error
				// message is not lost. Feel free to change this function.
				throw new SystemException("Error on Retrieving Post by ID", e);
			}
		} catch (JsonMappingException e) {
			throw new SystemException("Error on Retrieving Post by ID while parsing", e);
		} catch (JsonProcessingException e) {
			throw new SystemException("Error on Retrieving Post by ID while parsing", e);
		}
	}

    

    // TODO Write a method GET comments for a post from https://jsonplaceholder.typicode.com/posts/{postId}/comments - the comments must be returned as part of the post.
	public PostData getCommentsByPostId(final String id) {
		AuditionPost post = getPostById(id);
		PostData data = new PostData();
		data.setPost(post);
		String jsonResponse = restTemplate.getForObject(AUDITION_LIST_URL + "/" + id + "/comments", String.class);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			List<Comment> comments = objectMapper.readValue(jsonResponse, new TypeReference<List<Comment>>() {
			});
			data.setComments(comments);
		} catch (final HttpClientErrorException e) {
			if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
				throw new SystemException("Cannot find a Post with id " + id, "Resource Not Found", 404);
			} else {
				throw new SystemException("Error on Retrieving comments by ID", e);
			}
		} catch (JsonMappingException e) {
			throw new SystemException("Error on Retrieving comments by ID while parsing", e);
		} catch (JsonProcessingException e) {
			throw new SystemException("Error on Retrieving comments by ID while parsing", e);
		}
		return data;
	}
	

    // TODO write a method. GET comments for a particular Post from https://jsonplaceholder.typicode.com/comments?postId={postId}.
    // The comments are a separate list that needs to be returned to the API consumers. Hint: this is not part of the AuditionPost pojo.
	public PostData getCommentsByPostId1(final String id) {
		AuditionPost post = getPostById(id);
		PostData data = new PostData();
		data.setPost(post);
		String jsonResponse = restTemplate.getForObject("https://jsonplaceholder.typicode.com/comments?postId=" + id, String.class);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			List<Comment> comments = objectMapper.readValue(jsonResponse, new TypeReference<List<Comment>>() {
			});
			data.setComments(comments);
		} catch (final HttpClientErrorException e) {
			if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
				throw new SystemException("Cannot find a Post with id " + id, "Resource Not Found", 404);
			} else {
				throw new SystemException("Error on Retrieving Post by ID", e);
			}
		} catch (JsonMappingException e) {
			throw new SystemException("Error on Retrieving Post by ID while parsing", e);
		} catch (JsonProcessingException e) {
			throw new SystemException("Error on Retrieving Post by ID while parsing", e);
		}
		return data;
	}
}
